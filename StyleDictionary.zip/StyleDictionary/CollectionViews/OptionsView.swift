//
//  OptionsView.swift
//  StyleDictionary
//
//  Created by Pukar on 27/8/19.
//  Copyright © 2019 UOB. All rights reserved.
//

import UIKit

public protocol OptionViewDelegate {
    
    func didSelectItem(indexPath : IndexPath)
    
}
public struct CollectionViewData{
    var image : String?
    var title : String?
    
    public init(imagename: String, title: String){
        
        self.image = imagename
        self.title = title
    }
}
public class OptionsView: UIView {
    
    
    
    public var delegate: OptionViewDelegate?
    @IBOutlet weak var collectionView: UICollectionView!
    private let cellIdentifier = "OVCell"
    public var dataSource : [CollectionViewData]?
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadView()
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        loadView()
    }
    
    private func loadView(){
        
        
    }
    
}


extension OptionsView: UICollectionViewDelegate, UICollectionViewDataSource{
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataSource?.count ?? 0
    }
    
   public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OVCell", for: indexPath) as? OptionViewCell
        return cell ?? UICollectionViewCell.init()
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       delegate?.didSelectItem(indexPath: indexPath)
    }
    
    
}
