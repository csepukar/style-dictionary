//
//  OptionViewCell.swift
//  StyleDictionary
//
//  Created by Pukar on 27/8/19.
//  Copyright © 2019 UOB. All rights reserved.
//

import UIKit

class OptionViewCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
