//
//  PlayerView.swift
//  StyleDictionary
//
//  Created by Pukar on 27/8/19.
//  Copyright © 2019 UOB. All rights reserved.
//

import UIKit

class PlayerView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
