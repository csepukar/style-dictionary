//
//  HelloWorld.swift
//  StyleDictionary
//
//  Created by Pukar on 27/8/19.
//  Copyright © 2019 UOB. All rights reserved.
//

import UIKit

class HelloWorld: NSObject {
    
    func initialize(WithText : String){
        
    }
    

}
