//
//  StyleDictionary.h
//  StyleDictionary
//
//  Created by Pukar on 27/8/19.
//  Copyright © 2019 UOB. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for StyleDictionary.
FOUNDATION_EXPORT double StyleDictionaryVersionNumber;

//! Project version string for StyleDictionary.
FOUNDATION_EXPORT const unsigned char StyleDictionaryVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StyleDictionary/PublicHeader.h>


